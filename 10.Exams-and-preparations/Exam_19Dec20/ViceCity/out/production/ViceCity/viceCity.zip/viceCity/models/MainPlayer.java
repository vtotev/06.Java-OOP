package viceCity.models;

public class MainPlayer extends BasePlayer {
    public MainPlayer() {
        super("Tommy Vercetti", 100);
    }
}
