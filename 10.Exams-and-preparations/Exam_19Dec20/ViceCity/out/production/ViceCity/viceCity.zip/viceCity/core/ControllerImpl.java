package viceCity.core;

import viceCity.core.interfaces.Controller;
import viceCity.models.*;
import viceCity.models.guns.Gun;
import viceCity.models.neighbourhood.Neighbourhood;
import viceCity.models.players.Player;
import viceCity.repositories.GunRepository;

import java.util.*;
import java.util.stream.Collectors;

import static viceCity.common.ConstantMessages.*;

public class ControllerImpl implements Controller {
    private MainPlayer mainPlayer;
    private Collection<Player> players;
    private GunRepository guns;
    private Neighbourhood neighbourhood;

    public ControllerImpl() {
        mainPlayer = new MainPlayer();
        players = new ArrayList<>();
        this.guns = new GunRepository();
        neighbourhood = new GangNeighbourhood();
    }

    @Override
    public String addPlayer(String name) {
        players.add(new CivilPlayer(name));
        return String.format(PLAYER_ADDED, name);
    }

    @Override
    public String addGun(String type, String name) {
        Gun gun;
        switch (type) {
            case "Pistol":
                gun = new Pistol(name);
                break;
            case "Rifle":
                gun = new Rifle(name);
                break;
            default:
                throw new IllegalArgumentException(GUN_TYPE_INVALID);
        }
        guns.add(gun);
        return String.format(GUN_ADDED, name, type);
    }

    @Override
    public String addGunToPlayer(String name) {
        if (guns.getModels().size() == 0) {
            return String.format(GUN_QUEUE_IS_EMPTY);
        }
        List<Gun> collect = new ArrayList<>(guns.getModels());
        Gun gun = collect.get(0);
        if (name.equals("Vercetti")) {
            mainPlayer.getGunRepository().add(gun);
            guns.remove(gun);
            return String.format(GUN_ADDED_TO_MAIN_PLAYER, gun.getName(), "Tommy Vercetti");
        } else {
            Player civil = players.stream().filter(c -> c.getName().equals(name)).findFirst().orElse(null);
            if (civil == null) {
                return String.format(CIVIL_PLAYER_DOES_NOT_EXIST);
            }
            civil.getGunRepository().add(gun);
            guns.remove(gun);
            return String.format(GUN_ADDED_TO_CIVIL_PLAYER, gun.getName(), civil.getName());
        }
    }

    @Override
    public String fight() {
        int size = (int) players.stream().filter(Player::isAlive).count();
        neighbourhood.action(mainPlayer, players);
        int sizeAfter = (int) players.stream().filter(Player::isAlive).count();
        if (mainPlayer.getLifePoints() == 100 && size == sizeAfter) {
            return String.format(FIGHT_HOT_HAPPENED);
        }
        StringBuilder sb = new StringBuilder();
        sb.append(FIGHT_HAPPENED)
                .append(System.lineSeparator());
        sb.append(String.format(MAIN_PLAYER_LIVE_POINTS_MESSAGE, mainPlayer.getLifePoints()));
        sb.append(System.lineSeparator());
        sb.append(String.format(MAIN_PLAYER_KILLED_CIVIL_PLAYERS_MESSAGE, size - sizeAfter));
        sb.append(System.lineSeparator());
        sb.append(String.format(CIVIL_PLAYERS_LEFT_MESSAGE, sizeAfter));
        return sb.toString();
        //        neighbourhood.action(mainPlayer, players);
//        boolean fightNotHappened = mainPlayer.getLifePoints() == 100 && (players.stream().mapToInt(p -> p.getLifePoints()).average().orElse(0) == 50);
//        if (fightNotHappened) {
//            return FIGHT_HOT_HAPPENED;
//        }
//        return getShootoutResults();
    }

    public String getShootoutResults() {
        StringBuilder sb = new StringBuilder(FIGHT_HAPPENED + System.lineSeparator());
        sb.append(String.format(MAIN_PLAYER_LIVE_POINTS_MESSAGE, mainPlayer.getLifePoints())).append(System.lineSeparator());
        long killed = players.stream().filter(p -> !p.isAlive()).count();
        sb.append(String.format(MAIN_PLAYER_KILLED_CIVIL_PLAYERS_MESSAGE, killed)).append(System.lineSeparator());
        long alive = players.size() - killed;
        sb.append(String.format(CIVIL_PLAYERS_LEFT_MESSAGE, alive));
        players = players.stream().filter(p -> p.isAlive()).collect(Collectors.toCollection(ArrayList::new));
        return sb.toString();
    }
}
